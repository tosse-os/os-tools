<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;

class LogController extends Controller
{
    public function index()
    {
        $logPath = storage_path('logs/laravel.log');

        if (!File::exists($logPath)) {
            return view('logs.index', [
                'entries' => []
            ]);
        }

        $lines = array_reverse(file($logPath));

        $entries = [];

        foreach ($lines as $line) {

            if (preg_match('/^\[(.*?)\]\s+(\w+)\.(\w+):\s+(.*)$/', $line, $matches)) {
                $entries[] = [
                    'time' => $matches[1],
                    'env' => $matches[2],
                    'level' => $matches[3],
                    'message' => $matches[4],
                ];
            } else {
                $entries[] = [
                    'time' => '',
                    'env' => '',
                    'level' => '',
                    'message' => trim($line),
                ];
            }

            if (count($entries) >= 300) {
                break;
            }
        }

        return view('logs.index', compact('entries'));
    }
}
