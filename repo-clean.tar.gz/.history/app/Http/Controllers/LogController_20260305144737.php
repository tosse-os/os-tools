<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogController extends Controller
{
  public function index()
  {
    $path = storage_path('logs/laravel.log');

    if (!file_exists($path)) {
      return view('logs.index', [
        'logs' => []
      ]);
    }

    $lines = file($path);

    $logs = [];

    foreach (array_slice($lines, -200) as $line) {

      $line = preg_replace('/\e\[[\d;]*m/', '', $line);

      $logs[] = trim($line);
    }

    return view('logs.index', [
      'logs' => array_reverse($logs)
    ]);
  }

  public function raw()
  {
    $path = storage_path('logs/laravel.log');

    if (!file_exists($path)) {
      return response()->json([]);
    }

    $lines = file($path);

    $clean = [];

    foreach (array_slice($lines, -200) as $line) {

      $line = preg_replace('/\e\[[\d;]*m/', '', $line);

      $clean[] = trim($line);
    }

    return response()->json($clean);
  }
}
