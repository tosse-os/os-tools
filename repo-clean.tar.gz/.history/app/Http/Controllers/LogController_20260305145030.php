<?php

namespace App\Http\Controllers;

class LogController extends Controller
{
  public function index()
  {
    $path = storage_path('logs/laravel.log');

    if (!file_exists($path)) {
      return view('logs.index', [
        'entries' => []
      ]);
    }

    $lines = file($path);
    $entries = [];

    foreach (array_slice($lines, -200) as $line) {

      $line = preg_replace('/\e\[[\d;]*m/', '', $line);
      $line = trim($line);

      if (preg_match('/^\[(.*?)\]\s+(\w+)\.(\w+):\s+(.*)$/', $line, $matches)) {

        $entries[] = [
          'timestamp' => $matches[1],
          'environment' => $matches[2],
          'level' => strtolower($matches[3]),
          'message' => $matches[4],
        ];
      } else {

        $entries[] = [
          'timestamp' => '',
          'environment' => '',
          'level' => 'info',
          'message' => $line,
        ];
      }
    }

    return view('logs.index', [
      'entries' => array_reverse($entries)
    ]);
  }

  public function raw()
  {
    $path = storage_path('logs/laravel.log');

    if (!file_exists($path)) {
      return response()->json([]);
    }

    $lines = file($path);
    $clean = [];

    foreach (array_slice($lines, -200) as $line) {

      $line = preg_replace('/\e\[[\d;]*m/', '', $line);
      $clean[] = trim($line);
    }

    return response()->json($clean);
  }
}
