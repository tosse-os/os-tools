vendor frames

resources/views/queues/index.blade.php
:14
require
55 vendor frames collapsed

public/index.php
:20
require_once
1 vendor frame collapsed
resources/views/queues/index.blade.php :14
<h1 class="text-2xl font-semibold text-gray-900">System Logs</h1>
<p class="text-sm text-gray-500 mt-1">Recent application log events.</p>
</div>

<span class="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700 w-fit">
  {{ count($entries) }} entries
</span>
</div>


<div class="overflow-x-auto">
