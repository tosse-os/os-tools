ternal Server Error

ErrorException
Undefined property: stdClass::$queue
GET 127.0.0.1:8000
PHP 8.3.6 — Laravel 12.20.0

Expand
vendor frames

resources/views/queues/index.blade.php
:45
require
55 vendor frames collapsed

public/index.php
:20
require_once
1 vendor frame collapsed
resources/views/queues/index.blade.php :45
<td class="py-3 px-4 text-gray-700">
  {{ $job->id }}
</td>

<td class="py-3 px-4 text-gray-700">
  {{ $job->queue }}
</td>

<td class="py-3 px-4">

  <div class="font-semibold text-red-600">
