<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrawlPage extends Model
{
    use HasFactory;

    public $timestamps = false;
    const UPDATED_AT = null;

    protected $fillable = [
        'crawl_id',
        'url',
        'canonical_url',
        'status',
        'alt_count',
        'heading_count',
        'error',
        'content_hash',
        'internal_links_in',
        'internal_links_out',
        'depth',
        'created_at',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'internal_links_in' => 'integer',
        'internal_links_out' => 'integer',
        'depth' => 'integer',
    ];

    public function crawl()
    {
        return $this->belongsTo(Crawl::class);
    }
}
